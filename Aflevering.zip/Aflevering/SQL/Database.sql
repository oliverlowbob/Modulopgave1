CREATE DATABASE IF NOT EXISTS modulopgave1;

USE modulopgave1;


CREATE TABLE IF NOT EXISTS Koen
(
	idKoen			INT(5) 			NOT NULL	PRIMARY KEY,
    valueKoen		VARCHAR(10)		NOT NULL
);


CREATE TABLE IF NOT EXISTS Kommune
(
	idKommune 		INT(5)			NOT NULL	PRIMARY KEY,
    KommuneNavn		VARCHAR(30)			NOT NULL
);


CREATE TABLE IF NOT EXISTS Aar
(
	idAar			INT(5)				NOT NULL 	PRIMARY KEY,
    valueAar 		VARCHAR(4)			NOT NULL
);

CREATE TABLE IF NOT EXISTS Alder
(
	idAlder			INT(5)				NOT NULL	PRIMARY KEY,
    valueAlder		VARCHAR(25)			NOT NULL
);

CREATE TABLE IF NOT EXISTS Flytninger
(
	idFlytninger	INT(6)				NOT NULL AUTO_INCREMENT PRIMARY KEY,
    valueFlytninger	INT(10)				NOT NULL,
    idKoen			INT(6)				NOT NULL,
    idTilKommune	INT(6)				NOT NULL,
    idFraKommune	INT(6)				NOT NULL,
    idAar			INT(6)				NOT NULL,
    idAlder			INT(6)				NOT NULL,
    FOREIGN KEY	(idKoen)		REFERENCES Koen (idKoen),
    FOREIGN KEY	(idTilKommune) 	REFERENCES Kommune (idKommune),
    FOREIGN KEY (idFraKommune)	REFERENCES Kommune (idKommune),
    FOREIGN KEY	(idAar)			REFERENCES Aar (idAar),
    FOREIGN KEY	(idAlder)		REFERENCES Alder (idAlder)
);

  

  

  
