INSERT INTO Flytninger (valueFlytninger, idKoen, idAar, idAlder, idTilKommune, idFraKommune)
SELECT antal, Koen.idKoen, Aar.idAar, Alder.idAlder, Kommune.idKommune AS tilKommune, fraKommune.idKommune AS fraKommune FROM tiloutput
INNER JOIN Koen ON tiloutput.køn = Koen.valueKoen
INNER JOIN Aar ON tiloutput.aar = Aar.valueAar
INNER JOIN Alder ON tiloutput.alder = Alder.valueAlder
INNER JOIN Kommune ON tiloutput.tilflytningskommune = Kommune.KommuneNavn
INNER JOIN Kommune AS fraKommune ON tiloutput.fraflytningskommune = fraKommune.KommuneNavn
