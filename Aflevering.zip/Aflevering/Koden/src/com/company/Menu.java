package com.company;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class Menu {
    public static void runMenu(){
        boolean runProgram = true;
        while(runProgram)
        {
            int valg = 0;
            Scanner scanner = new Scanner(System.in);



            System.out.println("Database Menu");
            System.out.println("Vælg en funktion:");
            System.out.println("1: Søg på tilflytninger til by i årstal");
            System.out.println("0: Afslut");
           // System.out.println("2: Søg på flytninger af køn i årstal");
            // System.out.println("3: Søg på fraflytninger af alder i årstal");
            //System.out.println("4: Søg på tilflytninger til by i årstal");
            valg = scanner.nextInt();

            //if(valg==1)
               // showFraAarMenu();
            //if(valg==2)
               // showKoenAarMenu();
            //if(valg==3)
            //  showAlderAarMenu();
            if(valg==1)
                showTilAarMenu();
            if(valg==0)
                runProgram = false;

        }
    }

    public static void showFraAarMenu(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Indtast fraflyttet by");
        String fraBy = scanner.nextLine();
        System.out.println("Indtast årstal (mellem 2006 og 2017)");
        int aarstal = scanner.nextInt();



        /*SELECT Flytninger.fraKommune, Aar.valueAar, Flytninger.antal_flyninger FROM Flytninger
        INNER JOIN Aar ON Flytninger.Aar_idAar = Aar.idAar
        WHERE Aar.valueAar = aarstal AND Flytninger.fraKommune = fraBy*/


    }

    public static void showKoenAarMenu(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Indtast køn");
        String koen = scanner.nextLine();
        System.out.println("Indtast årstal(mellem 2006 og 2017)");
        int aarstal = scanner.nextInt();

        /*SELECT Flytninger.Køn_idKøn, Aar.valueAar, Flytninger.antal_flytninger
        FROM Flytninger
        INNER JOIN Køn
        ON Flytninger.Aar_idAar = Aar.idAar
        WHERE Køn.valueKøn = koen AND Aar.valueAar = aarstal*/
    }


    public static void showTilAarMenu() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Indtast tilflyttet by (1 for København, 2 for Frederiksberg");
        int tilBy = scanner.nextInt();
        System.out.println("Indtast årstal(mellem 2006 og 2017)");
        int aarstal = scanner.nextInt();

        String query = "SELECT Flytninger.idTilKommune, Aar.valueAar, Flytninger.valueFlytninger FROM Flytninger " +
        "INNER JOIN Aar ON Flytninger.idAar = Aar.idAar " +
        "WHERE Aar.valueAar = " + aarstal + " AND Flytninger.idTilKommune = " + tilBy;

        ResultSet set = runQuery(query);
        int sum = 0;

        try {
            set.beforeFirst();
            while(set.next()) {
                System.out.print(set.getString(1)+" ");
                System.out.print(set.getString(2)+" ");
                System.out.print(set.getString(3)+" ");
                System.out.println();
                sum += set.getInt(3);
            }
            System.out.println("Total tilflyttet: ");
            System.out.println(sum);
        } catch (SQLException e) {
            e.printStackTrace();
        }


        //ResultSetMetaData rsdata = set.getMetaData();


    }

    public static ResultSet runQuery(String query)
    {
        Statement st = null;
        try {
            st = Main.newConnection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            return st.executeQuery(query);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

}

