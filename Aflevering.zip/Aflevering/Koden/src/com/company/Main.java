package com.company;

import java.sql.Connection;
import java.sql.DriverManager;

public class Main {

    public static Connection newConnection;


    public static void main(String[] args) {

        try{
            newConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/modulopgave1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", "root", "dinfar");
            //jdbc:mysql://localhost/db?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC


        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        Menu.runMenu();
    }

}
